#!/bin/bash
echo "🚀 Installing CyberAI Agent from GitHub..."

apt update && apt install python3-pip unzip wget -y
cd /opt
wget https://github.com/NiKaDa2808/NiKaDa-client-setup/archive/refs/heads/main.zip -O client.zip
unzip -q client.zip
cd NiKaDa-client-setup-main

mkdir -p /opt/CyberAI-Client
cp agent.py update_client.sh version.txt /opt/CyberAI-Client/

read -p "Client Email: " EMAIL
read -s -p "Password: " PASSWORD
echo

cat <<EOF > /etc/systemd/system/cyberai-agent.service
[Unit]
Description=CyberAI Shield Agent
After=network.target

[Service]
User=root
WorkingDirectory=/opt/CyberAI-Client
ExecStart=/usr/bin/python3 /opt/CyberAI-Client/agent.py
Restart=always
Environment=CYBERAI_EMAIL=$EMAIL
Environment=CYBERAI_PASSWORD=$PASSWORD

[Install]
WantedBy=multi-user.target
EOF

chmod +x /opt/CyberAI-Client/agent.py
systemctl daemon-reexec
systemctl daemon-reload
systemctl enable cyberai-agent
systemctl start cyberai-agent

echo "✅ Agent installed and running!"
