#!/bin/bash
echo "🚀 Installing CyberAI Agent..."
apt update && apt install python3-pip wget -y
mkdir -p /opt/CyberAI-Client
cd /opt/CyberAI-Client

wget https://your-s3-bucket.com/client/agent.py -O agent.py
read -p "Client Email: " EMAIL
read -s -p "Password: " PASSWORD
echo

cat <<EOF > /etc/systemd/system/cyberai-agent.service
[Unit]
Description=CyberAI Shield Agent
After=network.target

[Service]
User=root
WorkingDirectory=/opt/CyberAI-Client
ExecStart=/usr/bin/python3 /opt/CyberAI-Client/agent.py
Restart=always
Environment=CYBERAI_EMAIL=$EMAIL
Environment=CYBERAI_PASSWORD=$PASSWORD

[Install]
WantedBy=multi-user.target
EOF

chmod +x agent.py
systemctl daemon-reexec
systemctl daemon-reload
systemctl enable cyberai-agent
systemctl start cyberai-agent
echo "✅ Agent installed and running!"
