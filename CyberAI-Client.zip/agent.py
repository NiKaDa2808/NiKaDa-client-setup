#!/usr/bin/env python3
import os, time, requests, json, psutil, platform

SERVER = "http://nikadatech.ddns.net"
AUTH_URL = f"{SERVER}/api/auth/login"
LOG_URL = f"{SERVER}/api/agent/logs"
VERSION_URL = "https://your-s3-bucket.com/client/version.txt"
UPDATE_SCRIPT = "https://your-s3-bucket.com/client/update_client.sh"
LOCAL_VERSION = "1.0.0"
TOKEN_FILE = "client_token.txt"
EMAIL = os.getenv("CYBERAI_EMAIL")
PASSWORD = os.getenv("CYBERAI_PASSWORD")

def authenticate():
    res = requests.post(AUTH_URL, json={"email": EMAIL, "password": PASSWORD})
    if res.status_code == 200:
        token = res.json().get("access_token")
        open(TOKEN_FILE, "w").write(token)
        return token
    return None

def get_token():
    return open(TOKEN_FILE).read().strip() if os.path.exists(TOKEN_FILE) else authenticate()

def check_for_update():
    try:
        r = requests.get(VERSION_URL)
        if r.ok and r.text.strip() != LOCAL_VERSION:
            os.system(f"wget {UPDATE_SCRIPT} -O update_client.sh && bash update_client.sh")
            exit()
    except Exception as e:
        print("Update check failed:", e)

def collect_system_stats():
    return {
        "cpu_percent": psutil.cpu_percent(),
        "memory_percent": psutil.virtual_memory().percent,
        "disk_percent": psutil.disk_usage('/').percent,
        "boot_time": psutil.boot_time(),
        "hostname": platform.node(),
        "platform": platform.system(),
        "running_processes": len(psutil.pids())
    }

def send_log():
    token = get_token()
    if not token: return
    headers = {"Authorization": f"Bearer {token}"}
    data = {
        "input_data": json.dumps(collect_system_stats()),
        "prediction_result": "system_status",
        "model_type": "agent_monitor"
    }
    try:
        res = requests.post(LOG_URL, json=data, headers=headers)
        print("Sent:", res.status_code)
    except Exception as e:
        print("Error sending log:", e)

if __name__ == "__main__":
    while True:
        check_for_update()
        send_log()
        time.sleep(60)
