#!/bin/bash
cd /opt/CyberAI-Client
wget https://your-s3-bucket.com/client/agent.py -O agent.py
systemctl restart cyberai-agent
echo "✅ Agent updated and restarted."
